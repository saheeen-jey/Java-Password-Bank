


import javax.swing.JPanel;

public abstract class State{
	protected JPanel panel = new JPanel();

	public JPanel getJPanel() {
		return panel;
		
	}
}
	