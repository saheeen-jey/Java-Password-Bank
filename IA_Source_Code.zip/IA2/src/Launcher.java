

public class Launcher {

	public static void main(String args[]) {
		@SuppressWarnings("unused")
		Display win = new Display("Password Manager", 1000,600);
	}
}
